from nltk.corpus import stopwords
import pandas as pd
import string
import nltk
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix

import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv("Restaurant reviews.csv")
data = data[["Review", "Rating"]].copy()

data["Rating"] = pd.to_numeric(data["Rating"], errors="coerce")
data = data.dropna(subset=["Review", "Rating"])

print("Broj recenzija:", len(data))


def mapiraj_sentiment(ocjena):
    if ocjena <= 2:
        return "negative"
    elif ocjena == 3:
        return "neutral"
    else:
        return "positive"


data["sentiment"] = data["Rating"].apply(mapiraj_sentiment)

print("\nRaspodjela klasa:")
broj_klasa = data["sentiment"].value_counts()
print(f"pozitivne recenzije: {broj_klasa.get('positive', 0)}")
print(f"negativne recenzije: {broj_klasa.get('negative', 0)}")
print(f"neutralne recenzije: {broj_klasa.get('neutral', 0)}")


stop_rijeci = set(stopwords.words("english"))

def obradi_tekst(tekst):
    tekst = str(tekst)
    bez_interpunkcije = [znak for znak in tekst if znak not in string.punctuation]
    bez_interpunkcije = "".join(bez_interpunkcije)
    tokeni = [
        word.lower()
        for word in bez_interpunkcije.split()
        if word.lower() not in stop_rijeci
    ]
    return tokeni


X = data["Review"]
Y = data["sentiment"]

X_trening, X_test, y_trening, y_test = train_test_split(
    X,
    Y,
    test_size=0.2,
    random_state=42,
    stratify=Y
)


priori_klasa = y_trening.value_counts(normalize=True)

model = Pipeline([
    ("vreca_rijeci", CountVectorizer(analyzer=obradi_tekst)),
    ("tfidf", TfidfTransformer()),
    ("klasifikator", MultinomialNB(
        class_prior=[
            priori_klasa["negative"],
            priori_klasa["neutral"],
            priori_klasa["positive"]
        ]
    ))
])


print("\nTreniranje modela...")
model.fit(X_trening, y_trening)
print("Model je uspješno treniran.")


predvidanja = model.predict(X_test)

izvjestaj = classification_report(y_test, predvidanja, output_dict=True)

prijevod = {
    "positive": "pozitivan",
    "negative": "negativan",
    "neutral": "neutralan"
}


print("\nKlasifikacijski izvještaj:")

for label in ["negative", "neutral", "positive"]:
    if label in izvjestaj:
        print(f"\nKlasa: {prijevod[label]}")
        print(f"  Preciznost: {izvjestaj[label]['precision']:.2f}")
        print(f"  Odaziv: {izvjestaj[label]['recall']:.2f}")
        print(f"  F1-mjera: {izvjestaj[label]['f1-score']:.2f}")
        print(f"  Broj uzoraka: {int(izvjestaj[label]['support'])}")

print(f"\nUkupna točnost: {izvjestaj['accuracy']:.2f}")
print(f"Makro prosjek F1: {izvjestaj['macro avg']['f1-score']:.2f}")
print(f"Ponderirani prosjek F1: {izvjestaj['weighted avg']['f1-score']:.2f}")



matrix = confusion_matrix(
    y_test, predvidanja,
    labels=["negative", "neutral", "positive"]
)

plt.figure(figsize=(5, 4))
sns.heatmap(
    matrix,
    annot=True,
    fmt="d",
    xticklabels=["negativan", "neutralan", "pozitivan"],
    yticklabels=["negativan", "neutralan", "pozitivan"]
)
plt.xlabel("Predviđeno")
plt.ylabel("Stvarno")
plt.title("Matrica zabune – klasifikacija sentimenta")
plt.tight_layout()
plt.show()



def analiziraj_recenzije():
    print("\nAnaliza sentimenta recenzija")
    print("(upiši 'exit' za izlaz)")

    while True:
        unos = input("\nUnesite recenziju: ")

        if unos.lower() in ["exit", "kraj", "quit"]:
            print("Izlaz iz aplikacije.")
            break

        rezultat = model.predict([unos])[0]
        print(f"Ova recenzija je {prijevod[rezultat]}.")



if __name__ == "__main__":
    analiziraj_recenzije()


