# UUI_analiza_ugostiteljstvo
Projekt iz kolegija Uvod u umjetnu inteligenciju – Procesiranje prirodnog jezika za razumijevanje povratnih informacija klijenata u ugostiteljskoj industriji.


# Procesiranje prirodnog jezika za razumijevanje povratnih informacija klijenata u ugostiteljskoj industriji.

Cilj projekta je izrada jednostavne aplikacije za analizu sentimenta tekstualnih recenzija restorana primjenom metoda obrade prirodnog jezika i nadziranog strojnog učenja.

Aplikacija omogućuje treniranje modela na skupu recenzija te interaktivnu analizu sentimenta novih recenzija koje korisnik unosi putem konzole.

## Korištene tehnologije
- Python
- NLTK
- scikit-learn
- Bag-of-Words
- TF-IDF
- Multinomial Naive Bayes
- pandas
- scikit-learn
- nltk
- matplotlib
- seaborn

## Skup podataka

Za treniranje i evaluaciju modela korišten je javno dostupan skup podataka s platforme Kaggle:

https://www.kaggle.com/datasets/joebeachcapital/restaurant-reviews

Skup podataka sadrži tekstualne recenzije restorana i pripadajuće numeričke ocjene korisnika.


## Pokretanje aplikacije

1. Instalirati potrebne biblioteke:
pip install pandas nltk scikit-learn matplotlib seaborn

2. Preuzeti "Restaurant reviews.csv" i spremiti ga u istu mapu kao i kod

3. Pokrenuti aplikaciju:
python a_s_maric.py

4. Za izlaz iz aplikacije potrebno je upisati:
exit


Cijeli repozitorij se nalazi na sljedećoj poveznici: https://github.com/SMaric23/UUI_analiza_ugostiteljstvo.git
